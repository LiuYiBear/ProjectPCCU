package com.example.user.myapplication;



public class Config {
    public static final String THEME_CONFIG="theme_config";
}
