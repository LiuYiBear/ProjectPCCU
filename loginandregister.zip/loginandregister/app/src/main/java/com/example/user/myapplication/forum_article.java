package com.example.user.myapplication;

import android.support.v7.app.AppCompatActivity;

public class forum_article extends AppCompatActivity {
}
