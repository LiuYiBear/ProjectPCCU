<?php

$conn = mysqli_connect("localhost", "jack", "0000", "users");
/*users是資料庫名稱$conn = mysqli_connect("localhost", "root", "root", "users");*/

?>